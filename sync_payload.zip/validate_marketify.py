"""Unified validation runner for Marketify paper-trading engine.

Runs import smoke, pytest, audit/risk log checks, drift checks.
Outputs reports/validation_summary.json and reports/validation_summary.md
"""
from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPORTS_DIR = Path("reports")


def _ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def run_import_smoke() -> dict[str, Any]:
    """Verify all core modules import without error."""
    errors: list[str] = []
    modules = [
        "marketify.config",
        "marketify.broker.paper",
        "marketify.broker.ibkr",
        "marketify.risk.risk_engine",
        "marketify.state.store",
        "marketify.models.xgb_model",
        "marketify.models.ensemble",
        "marketify.models.drift",
        "marketify.models.train_pipeline",
        "marketify.backtest.benchmark",
        "marketify.backtest.simulator",
        "marketify.onboarding",
        "marketify.data.market_data",
        "marketify.features.technical",
    ]
    for mod in modules:
        try:
            __import__(mod)
        except Exception as e:
            errors.append(f"{mod}: {e}")
    return {"name": "import_smoke", "passed": len(errors) == 0, "errors": errors}


def run_pytest() -> dict[str, Any]:
    """Run pytest and capture result."""
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "--tb=short"],
        capture_output=True,
        text=True,
        cwd=str(Path(__file__).resolve().parent.parent),
    )
    return {
        "name": "pytest",
        "passed": result.returncode == 0,
        "returncode": result.returncode,
        "stdout": result.stdout[-2000:] if result.stdout else "",
        "stderr": result.stderr[-1000:] if result.stderr else "",
    }


def run_audit_smoke() -> dict[str, Any]:
    """Create a temp PaperBroker and verify audit/risk tables exist."""
    import tempfile
    from marketify.broker.paper import PaperBroker
    from marketify.config import BrokerConfig

    with tempfile.TemporaryDirectory() as td:
        cfg = BrokerConfig(db_path=str(Path(td) / "test.db"))
        broker = PaperBroker(cfg)
        broker.append_audit("smoke_test", "ok")
        broker.append_risk_event("smoke_test", "info", "validation smoke")
        audit = broker.get_audit_log(limit=1)
        risk = broker.get_risk_events(limit=1)
        return {
            "name": "audit_smoke",
            "passed": len(audit) == 1 and len(risk) == 1,
            "audit_count": len(audit),
            "risk_count": len(risk),
        }


def run_drift_smoke() -> dict[str, Any]:
    """Run drift checker on synthetic data."""
    import numpy as np
    import pandas as pd
    from marketify.models.drift import check_prediction_drift

    baseline = pd.Series(np.random.normal(0, 0.01, 100))
    recent = pd.Series(np.random.normal(0.02, 0.01, 30))
    result = check_prediction_drift(recent, baseline)
    return {
        "name": "drift_smoke",
        "passed": result.level in ("none", "warning", "critical"),
        "drift_level": result.level,
        "reason": result.reason,
    }


def run_benchmark_smoke() -> dict[str, Any]:
    """Run benchmark checker on synthetic equity history."""
    from marketify.backtest.benchmark import compute_benchmark
    history = [
        {"ts": f"2026-01-0{i+1}T00:00:00", "equity": 10000 + i * 50}
        for i in range(7)
    ]
    result = compute_benchmark(history, weekly_goal=0.01)
    return {
        "name": "benchmark_smoke",
        "passed": True,
        "weekly_return": result.weekly_return,
        "weekly_pass": result.weekly_pass,
        "max_drawdown": result.max_drawdown,
    }


def run_all() -> dict[str, Any]:
    """Run all validations and return combined report."""
    results: list[dict[str, Any]] = []
    results.append(run_import_smoke())
    results.append(run_pytest())
    results.append(run_audit_smoke())
    results.append(run_drift_smoke())
    results.append(run_benchmark_smoke())

    all_passed = all(r["passed"] for r in results)
    report = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "all_passed": all_passed,
        "results": results,
    }
    return report


def save_reports(report: dict[str, Any]) -> tuple[Path, Path]:
    """Save validation report as JSON and Markdown."""
    _ensure_dir(REPORTS_DIR)
    json_path = REPORTS_DIR / "validation_summary.json"
    md_path = REPORTS_DIR / "validation_summary.md"

    with open(json_path, "w") as f:
        json.dump(report, f, indent=2)

    lines = [
        "# Marketify Validation Summary",
        f"**Timestamp:** {report['timestamp']}",
        f"**Overall:** {'PASS' if report['all_passed'] else 'FAIL'}",
        "",
        "| Check | Status |",
        "|-------|--------|",
    ]
    for r in report["results"]:
        status = "PASS" if r["passed"] else "FAIL"
        lines.append(f"| {r['name']} | {status} |")
    lines.append("")

    for r in report["results"]:
        if not r["passed"]:
            lines.append(f"### {r['name']} - FAIL")
            for k, v in r.items():
                if k not in ("name", "passed"):
                    lines.append(f"- {k}: {v}")
            lines.append("")

    with open(md_path, "w") as f:
        f.write("\n".join(lines))

    return json_path, md_path


def generate_next_status(report: dict[str, Any]) -> Path:
    """Generate reports/NEXT_STATUS.md from validation report."""
    _ensure_dir(REPORTS_DIR)
    path = REPORTS_DIR / "NEXT_STATUS.md"

    passed = [r for r in report["results"] if r["passed"]]
    failed = [r for r in report["results"] if not r["passed"]]

    lines = [
        "# NEXT_STATUS — Marketify Paper Engine",
        f"**Generated:** {report['timestamp']}",
        f"**Overall:** {'PASS' if report['all_passed'] else 'FAIL'}",
        "",
        "## Passed Controls",
    ]
    for r in passed:
        lines.append(f"- {r['name']}")
    lines.append("")
    lines.append("## Failed Controls")
    if failed:
        for r in failed:
            lines.append(f"- {r['name']}")
            for k, v in r.items():
                if k not in ("name", "passed"):
                    lines.append(f"  - {k}: {v}")
    else:
        lines.append("- None")
    lines.append("")
    lines.append("## Blockers")
    lines.append("- Colab runtime: unavailable (local ipykernel used)")
    lines.append("- IBKR live connection: not tested (skeleton only)")
    lines.append("")
    lines.append("## Disclaimer")
    lines.append(
        "Experimental paper-trading engine. No financial advice. "
        "Trading involves risk, including loss of principal. "
        "Target metrics are benchmarks, not guarantees."
    )

    with open(path, "w") as f:
        f.write("\n".join(lines))

    return path


if __name__ == "__main__":
    report = run_all()
    json_path, md_path = save_reports(report)
    status_path = generate_next_status(report)
    overall = "PASS" if report["all_passed"] else "FAIL"
    print(f"Validation: {overall}")
    print(f"  JSON: {json_path}")
    print(f"  MD:   {md_path}")
    print(f"  Status: {status_path}")
    for r in report["results"]:
        tag = "PASS" if r["passed"] else "FAIL"
        print(f"  [{tag}] {r['name']}")
